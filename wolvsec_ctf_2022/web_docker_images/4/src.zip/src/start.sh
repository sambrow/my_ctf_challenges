#!/bin/bash

node /ctf/app/private1.js&
node /ctf/app/private2.js&
node /ctf/app/public.js